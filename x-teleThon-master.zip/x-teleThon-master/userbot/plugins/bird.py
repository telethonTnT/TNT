"""Emoji

Available Commands:

.br

if u edit it then u r gay"""

from telethon import events

import asyncio





@borg.on(events.NewMessage(pattern=r"\.(.*)", outgoing=True))

async def _(event):

    if event.fwd_from:

        return

    animation_interval = 0.3

    animation_ttl = range(0, 12)

    input_str = event.pattern_match.group(1)

    if input_str == "br":

        await event.edit(input_str)

        animation_chars = [
        
            "🕊🕊🕊🔲🔲🔲💞💞💞\n🕊🕊🕊🔲🔲🔲💞💞💞\n🕊🕊🕊🔲🔲🔲💞💞💞",
            "💞💞💞🔲🔲🔲🕊🕊🕊\n💞💞💞🔲🔲🔲🕊🕊🕊\n💞💞💞🔲🔲🔲🕊🕊🕊",
            "🕊🕊🕊🔲🔲🔲💞💞💞\n🕊🕊🕊🔲🔲🔲💞💞💞\n🕊🕊🕊🔲🔲🔲💞💞💞",
            "💞💞💞🔲🔲🔲🕊🕊🕊\n💞💞💞🔲🔲🔲🕊🕊🕊\n💞💞💞🔲🔲🔲🕊🕊🕊",
            "🕊🕊🕊🔲🔲🔲💞💞💞\n🕊🕊🕊🔲🔲🔲💞💞💞\n🕊🕊🕊🔲🔲🔲💞💞💞",    
            "💞💞💞🔲🔲🔲🕊🕊🕊\n💞💞💞🔲🔲🔲🕊🕊🕊\n💞💞💞🔲🔲🔲🕊🕊🕊",
            "🕊🕊🕊🔲🔲🔲💞💞💞\n🕊🕊🕊🔲🔲🔲💞💞💞\n🕊🕊🕊🔲🔲🔲💞💞💞",
            "💞💞💞🔲🔲🔲🕊🕊🕊\n💞💞💞🔲🔲🔲🕊🕊🕊\n💞💞💞🔲🔲🔲🕊🕊🕊",
            "🕊🕊🕊🔲🔲🔲💞💞💞\n🕊🕊🕊🔲🔲🔲💞💞💞\n🕊🕊🕊🔲🔲🔲💞💞💞",
            "💞💞💞🔲🔲🔲🕊🕊🕊\n💞💞💞🔲🔲🔲🕊🕊🕊\n💞💞💞🔲🔲🔲🕊🕊🕊",
            "🕊🕊🕊🔲🔲🔲💞💞💞\n🕊🕊🕊🔲🔲🔲💞💞💞\n🕊🕊🕊🔲🔲🔲💞💞💞",
            "@xtelethon"

 ]

        for i in animation_ttl:

            await asyncio.sleep(animation_interval)

            await event.edit(animation_chars[i % 12])
